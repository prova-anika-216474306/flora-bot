'use strict';

// Import the Dialogflow module from the Actions on Google client library.
const {dialogflow} = require('actions-on-google');
const {
     Card,
     Suggestion
 } = require('dialogflow-fulfillment');
// Import the firebase-functions package for deployment.
const functions = require('firebase-functions');

// Instantiate the Dialogflow client.
const app = dialogflow({debug: true});
let sex;
let pain;
let discharge;
let diagnosis;
app.intent('feeling', (conv, params) => {
    const mood = params.mood;
    if(mood == 'good'){
      conv.ask('That \'s good to hear! Can I help you with some symptoms that you are experiencing?');
    }
  else{
    conv.ask('Oh no, sorry about that! If it is because you have some symptoms, you came to the right place! Do you have any symptoms today?');
  }
});

app.intent('feeling-sex', (conv, params) =>{
  sex = params.sex;
  //conv.ask('Alright. Now, are you feeling any kind of discomfort? Common types can be \'pain during urination\' , \'pain during sex\', \'pain in lower abdomen\'');
});

app.intent('feeling-pain', (conv, params) => {
  if(params.pain){
     pain = params.pain;
  }
  //conv.ask('Noted. Now, is there any irregularity with your discharge?'
  //+ '\nThere could be change in color. These color can be green, yellow, or red.\nThere could be change in texture. Such as cottag cheese-like. You might also experience fishy smell.');
});

app.intent('feeling-discharge', (conv, params) => {
  if(params.discharge){
     discharge = params.discharge;
  }
 	diagnosis = getDiagnosis();
  if(diagnosis == 'no'){
    conv.ask('Okay! These are some good information. Based on your symptom, you might not have any health issues, but facing hormonal change or even early pregnancy. Do you want to learn more about our natural hormone level?'+
            'type \'Hormone\' to learn more.');
  }
  else{
    conv.ask('Okay! These are some good information. Based on your symptom, you might have ' + diagnosis + '. Don\'t worry, do you want to learn more about your diagnosis?'+
            ' Type \'' + diagnosis+'\' to learn more.');
  }
  
});

function getDiagnosis(){
  if((sex == 'no' && pain == 'urination' )|| (sex == 'active' && !discharge)){
    return 'Bladder infection';
  }
  else if(discharge == 'fish'){
    return 'Bacterial vaginosis (BV)';
  }
  else if(discharge == 'cheese'){
    return 'Yeast infection';
  }
  else if(sex == 'active' && discharge == 'yellowgreen'){
    return 'Trichomoniasis';
  }
  else if(sex == 'active' && discharge == 'red' && pain == 'urination'){
    return 'Chlamydia';
  }
  return 'no';
}

// Set the DialogflowApp object to handle the HTTPS POST request.
exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);